#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_11 {union overhead overhead; char data [1];};
struct eif_ex_21 {union overhead overhead; char data [1];};
struct eif_ex_188 {union overhead overhead; char data [8];};
struct eif_ex_191 {union overhead overhead; char data [8];};
struct eif_ex_194 {union overhead overhead; char data [8];};
struct eif_ex_197 {union overhead overhead; char data [8];};
struct eif_ex_200 {union overhead overhead; char data [8];};
struct eif_ex_203 {union overhead overhead; char data [8];};
struct eif_ex_206 {union overhead overhead; char data [8];};
struct eif_ex_209 {union overhead overhead; char data [8];};
struct eif_ex_212 {union overhead overhead; char data [8];};
struct eif_ex_215 {union overhead overhead; char data [8];};
struct eif_ex_218 {union overhead overhead; char data [8];};
struct eif_ex_221 {union overhead overhead; char data [8];};
struct eif_ex_224 {union overhead overhead; char data [8];};
struct eif_ex_227 {union overhead overhead; char data [8];};
struct eif_ex_247 {union overhead overhead; char data [8];};
struct eif_ex_252 {union overhead overhead; char data [8];};
struct eif_ex_258 {union overhead overhead; char data [8];};
struct eif_ex_358 {union overhead overhead; char data [8];};
struct eif_ex_432 {union overhead overhead; char data [8];};
struct eif_ex_436 {union overhead overhead; char data [8];};
struct eif_ex_445 {union overhead overhead; char data [8];};
struct eif_ex_449 {union overhead overhead; char data [8];};
struct eif_ex_453 {union overhead overhead; char data [8];};
struct eif_ex_470 {union overhead overhead; char data [8];};
struct eif_ex_545 {union overhead overhead; char data [8];};
struct eif_ex_572 {union overhead overhead; char data [8];};
struct eif_ex_861 {union overhead overhead; char data [8];};
struct eif_ex_866 {union overhead overhead; char data [8];};
struct eif_ex_881 {union overhead overhead; char data [8];};

#ifdef __cplusplus
}
#endif
#endif
